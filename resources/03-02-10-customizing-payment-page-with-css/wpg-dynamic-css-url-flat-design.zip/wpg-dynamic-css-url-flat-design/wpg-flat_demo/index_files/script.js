$(document).ready(function() {
	$('#hpp-pm-selection-toggle').click(function() {
		$('#hpp-pm-selection > .panel-heading').toggle();
	});
	$('.customInputPanel').click(function() {
		$('#hpp-pm-selection > .panel-heading').toggle();
	});
	
	var pmImgs = $('.hpp-payment-method img');
	if (pmImgs.length < 5) {
		pmImgs.css('max-height','80px');
	}
});